using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using MiniMarketERP.Entities;

namespace MiniMarketERP.DataAccess
{
    public class TedarikDAL
    {
        public void AlimKaydet(Alim alim)
        {
            using (var conn = DbHelper.GetConnection())
            {
                conn.Open();
                using (var transaction = conn.BeginTransaction())
                {
                    try
                    {
                        var cmd = new SqlCommand("INSERT INTO Alimlar (Tedarikci_Id, Urun_Id, Miktar, Birim_Alis_Fiyati, Alim_Tarihi) VALUES (@Tedarikci_Id, @Urun_Id, @Miktar, @Birim_Alis_Fiyati, @Alim_Tarihi)", conn, transaction);
                        cmd.Parameters.AddWithValue("@Tedarikci_Id", alim.Tedarikci_Id);
                        cmd.Parameters.AddWithValue("@Urun_Id", alim.Urun_Id);
                        cmd.Parameters.AddWithValue("@Miktar", alim.Miktar);
                        cmd.Parameters.AddWithValue("@Birim_Alis_Fiyati", alim.Birim_Alis_Fiyati);
                        cmd.Parameters.AddWithValue("@Alim_Tarihi", alim.Alim_Tarihi);
                        
                        cmd.ExecuteNonQuery();

                        // Stok artır
                        var cmdStok = new SqlCommand("UPDATE Urunler SET Adet = Adet + @Miktar WHERE Urun_Id = @Urun_Id", conn, transaction);
                        cmdStok.Parameters.AddWithValue("@Miktar", alim.Miktar);
                        cmdStok.Parameters.AddWithValue("@Urun_Id", alim.Urun_Id);
                        cmdStok.ExecuteNonQuery();

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
        
        public List<Tedarikci> TedarikciListele()
        {
            var list = new List<Tedarikci>();
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT * FROM Tedarikciler", conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Tedarikci
                        {
                            Tedarikci_Id = Convert.ToInt32(reader["Tedarikci_Id"]),
                            FirmaAdi = reader["FirmaAdi"].ToString(),
                            Iletisim = reader["Iletisim"] != DBNull.Value ? reader["Iletisim"].ToString() : null
                        });
                    }
                }
            }
            return list;
        }

        public System.Data.DataTable AlimListele()
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT * FROM Alimlar", conn);
                var dt = new System.Data.DataTable();
                var da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                return dt;
            }
        }

        public void AlimGuncelle(Alim alim)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("UPDATE Alimlar SET Tedarikci_Id=@Tedarikci_Id, Urun_Id=@Urun_Id, Miktar=@Miktar, Birim_Alis_Fiyati=@Birim_Alis_Fiyati, Alim_Tarihi=@Alim_Tarihi WHERE Alim_Id=@Alim_Id", conn);
                cmd.Parameters.AddWithValue("@Alim_Id", alim.Alim_Id);
                cmd.Parameters.AddWithValue("@Tedarikci_Id", alim.Tedarikci_Id);
                cmd.Parameters.AddWithValue("@Urun_Id", alim.Urun_Id);
                cmd.Parameters.AddWithValue("@Miktar", alim.Miktar);
                cmd.Parameters.AddWithValue("@Birim_Alis_Fiyati", alim.Birim_Alis_Fiyati);
                cmd.Parameters.AddWithValue("@Alim_Tarihi", alim.Alim_Tarihi);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void AlimSil(int alimId)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("DELETE FROM Alimlar WHERE Alim_Id=@Alim_Id", conn);
                cmd.Parameters.AddWithValue("@Alim_Id", alimId);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public decimal BorcSorgula(int tedarikciId)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT ISNULL(SUM(Miktar * Birim_Alis_Fiyati), 0) FROM Alimlar WHERE Tedarikci_Id=@Tedarikci_Id", conn);
                cmd.Parameters.AddWithValue("@Tedarikci_Id", tedarikciId);
                conn.Open();
                return Convert.ToDecimal(cmd.ExecuteScalar());
            }
        }
    }
}
