using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using MiniMarketERP.Entities;

namespace MiniMarketERP.DataAccess
{
    public class SatisDAL
    {
        public int SatisKaydet(Satis satis, List<SatisDetay> detaylar)
        {
            using (var conn = DbHelper.GetConnection())
            {
                conn.Open();
                using (var transaction = conn.BeginTransaction())
                {
                    try
                    {
                        var cmd = new SqlCommand("INSERT INTO Satislar (Musteri_Id, Tutar, Tarih, Satis_Durumu) OUTPUT INSERTED.Satis_Id VALUES (@Musteri_Id, @Tutar, @Tarih, @Satis_Durumu)", conn, transaction);
                        cmd.Parameters.AddWithValue("@Musteri_Id", satis.Musteri_Id.HasValue ? (object)satis.Musteri_Id.Value : DBNull.Value);
                        cmd.Parameters.AddWithValue("@Tutar", satis.Tutar);
                        cmd.Parameters.AddWithValue("@Tarih", satis.Tarih);
                        cmd.Parameters.AddWithValue("@Satis_Durumu", satis.Satis_Durumu);

                        int satisId = (int)cmd.ExecuteScalar();

                        foreach (var detay in detaylar)
                        {
                            var cmdDetay = new SqlCommand("INSERT INTO SatisDetaylari (Satis_Id, Urun_Id, Miktar, BirimFiyat) VALUES (@Satis_Id, @Urun_Id, @Miktar, @BirimFiyat)", conn, transaction);
                            cmdDetay.Parameters.AddWithValue("@Satis_Id", satisId);
                            cmdDetay.Parameters.AddWithValue("@Urun_Id", detay.Urun_Id);
                            cmdDetay.Parameters.AddWithValue("@Miktar", detay.Miktar);
                            cmdDetay.Parameters.AddWithValue("@BirimFiyat", detay.BirimFiyat);
                            cmdDetay.ExecuteNonQuery();

                            // Stok düş
                            var cmdStok = new SqlCommand("UPDATE Urunler SET Adet = Adet - @Miktar WHERE Urun_Id = @Urun_Id", conn, transaction);
                            cmdStok.Parameters.AddWithValue("@Miktar", detay.Miktar);
                            cmdStok.Parameters.AddWithValue("@Urun_Id", detay.Urun_Id);
                            cmdStok.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        return satisId;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }
        public System.Data.DataTable SatisListele()
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT S.Satis_Id, S.Tutar, S.Tarih, S.Musteri_Id, O.OdemeTipi AS Odeme_Yontemi, S.Satis_Durumu FROM Satislar S LEFT JOIN Odemeler O ON S.Satis_Id = O.Satis_Id", conn);
                var dt = new System.Data.DataTable();
                var da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                return dt;
            }
        }
    }
}
