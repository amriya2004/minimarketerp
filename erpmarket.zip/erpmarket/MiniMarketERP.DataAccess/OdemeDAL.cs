using System;
using System.Data.SqlClient;
using MiniMarketERP.Entities;

namespace MiniMarketERP.DataAccess
{
    public class OdemeDAL
    {
        public void OdemeKaydet(Odeme odeme)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("INSERT INTO Odemeler (Satis_Id, Musteri_Id, OdemeTipi, Tutar, Tarih) VALUES (@Satis_Id, @Musteri_Id, @OdemeTipi, @Tutar, @Tarih)", conn);
                cmd.Parameters.AddWithValue("@Satis_Id", odeme.Satis_Id.HasValue ? (object)odeme.Satis_Id.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@Musteri_Id", odeme.Musteri_Id.HasValue ? (object)odeme.Musteri_Id.Value : DBNull.Value);
                cmd.Parameters.AddWithValue("@OdemeTipi", odeme.OdemeTipi);
                cmd.Parameters.AddWithValue("@Tutar", odeme.Tutar);
                cmd.Parameters.AddWithValue("@Tarih", odeme.Tarih);
                
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
        
        public System.Data.DataTable OdemeListele()
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT * FROM Odemeler", conn);
                var dt = new System.Data.DataTable();
                var da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                return dt;
            }
        }

        public void IadeKaydet(Odeme odeme)
        {
            // İade için tutarı eksi olarak kaydediyoruz
            odeme.Tutar = -Math.Abs(odeme.Tutar);
            OdemeKaydet(odeme);
        }
    }
}
