using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using MiniMarketERP.Entities;

namespace MiniMarketERP.DataAccess
{
    public class MusteriDAL
    {
        public void Ekle(Musteri musteri)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("INSERT INTO Musteriler (Ad, Soyad, Telefon, Eposta, Guncel_Borc) VALUES (@Ad, @Soyad, @Telefon, @Eposta, @Guncel_Borc)", conn);
                cmd.Parameters.AddWithValue("@Ad", musteri.Ad);
                cmd.Parameters.AddWithValue("@Soyad", musteri.Soyad);
                cmd.Parameters.AddWithValue("@Telefon", musteri.Telefon ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Eposta", musteri.Eposta ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Guncel_Borc", musteri.Guncel_Borc);
                
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Guncelle(Musteri musteri)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("UPDATE Musteriler SET Ad=@Ad, Soyad=@Soyad, Telefon=@Telefon, Eposta=@Eposta, Guncel_Borc=@Guncel_Borc WHERE Musteri_Id=@Musteri_Id", conn);
                cmd.Parameters.AddWithValue("@Musteri_Id", musteri.Musteri_Id);
                cmd.Parameters.AddWithValue("@Ad", musteri.Ad);
                cmd.Parameters.AddWithValue("@Soyad", musteri.Soyad);
                cmd.Parameters.AddWithValue("@Telefon", musteri.Telefon ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Eposta", musteri.Eposta ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Guncel_Borc", musteri.Guncel_Borc);
                
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Sil(int musteriId)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("DELETE FROM Musteriler WHERE Musteri_Id=@Musteri_Id", conn);
                cmd.Parameters.AddWithValue("@Musteri_Id", musteriId);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<Musteri> Listele()
        {
            var list = new List<Musteri>();
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT * FROM Musteriler", conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Musteri
                        {
                            Musteri_Id = Convert.ToInt32(reader["Musteri_Id"]),
                            Ad = reader["Ad"].ToString(),
                            Soyad = reader["Soyad"].ToString(),
                            Telefon = reader["Telefon"] != DBNull.Value ? reader["Telefon"].ToString() : null,
                            Eposta = reader["Eposta"] != DBNull.Value ? reader["Eposta"].ToString() : null,
                            Guncel_Borc = Convert.ToDecimal(reader["Guncel_Borc"])
                        });
                    }
                }
            }
            return list;
        }
        
        public void BorcGuncelle(int musteriId, decimal degisimMiktari)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("UPDATE Musteriler SET Guncel_Borc = Guncel_Borc + @Miktar WHERE Musteri_Id=@Musteri_Id", conn);
                cmd.Parameters.AddWithValue("@Miktar", degisimMiktari);
                cmd.Parameters.AddWithValue("@Musteri_Id", musteriId);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
