using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using MiniMarketERP.Entities;

namespace MiniMarketERP.DataAccess
{
    public class UrunDAL
    {
        public void Ekle(Urun urun)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("INSERT INTO Urunler (Barkod, Ad, Kategori, Adet, Alis_Fiyati, Satis_Fiyati, Kritik_Stok_Seviyesi) VALUES (@Barkod, @Ad, @Kategori, @Adet, @Alis_Fiyati, @Satis_Fiyati, @Kritik_Stok_Seviyesi)", conn);
                cmd.Parameters.AddWithValue("@Barkod", urun.Barkod);
                cmd.Parameters.AddWithValue("@Ad", urun.Ad);
                cmd.Parameters.AddWithValue("@Kategori", urun.Kategori ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Adet", urun.Adet);
                cmd.Parameters.AddWithValue("@Alis_Fiyati", urun.Alis_Fiyati);
                cmd.Parameters.AddWithValue("@Satis_Fiyati", urun.Satis_Fiyati);
                cmd.Parameters.AddWithValue("@Kritik_Stok_Seviyesi", urun.Kritik_Stok_Seviyesi);
                
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Guncelle(Urun urun)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("UPDATE Urunler SET Barkod=@Barkod, Ad=@Ad, Kategori=@Kategori, Adet=@Adet, Alis_Fiyati=@Alis_Fiyati, Satis_Fiyati=@Satis_Fiyati, Kritik_Stok_Seviyesi=@Kritik_Stok_Seviyesi WHERE Urun_Id=@Urun_Id", conn);
                cmd.Parameters.AddWithValue("@Urun_Id", urun.Urun_Id);
                cmd.Parameters.AddWithValue("@Barkod", urun.Barkod);
                cmd.Parameters.AddWithValue("@Ad", urun.Ad);
                cmd.Parameters.AddWithValue("@Kategori", urun.Kategori ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Adet", urun.Adet);
                cmd.Parameters.AddWithValue("@Alis_Fiyati", urun.Alis_Fiyati);
                cmd.Parameters.AddWithValue("@Satis_Fiyati", urun.Satis_Fiyati);
                cmd.Parameters.AddWithValue("@Kritik_Stok_Seviyesi", urun.Kritik_Stok_Seviyesi);
                
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Sil(int urunId)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("DELETE FROM Urunler WHERE Urun_Id=@Urun_Id", conn);
                cmd.Parameters.AddWithValue("@Urun_Id", urunId);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<Urun> Listele()
        {
            var list = new List<Urun>();
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT * FROM Urunler", conn);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Urun
                        {
                            Urun_Id = Convert.ToInt32(reader["Urun_Id"]),
                            Barkod = reader["Barkod"].ToString(),
                            Ad = reader["Ad"].ToString(),
                            Kategori = reader["Kategori"] != DBNull.Value ? reader["Kategori"].ToString() : null,
                            Adet = Convert.ToInt32(reader["Adet"]),
                            Alis_Fiyati = Convert.ToDecimal(reader["Alis_Fiyati"]),
                            Satis_Fiyati = Convert.ToDecimal(reader["Satis_Fiyati"]),
                            Kritik_Stok_Seviyesi = Convert.ToInt32(reader["Kritik_Stok_Seviyesi"])
                        });
                    }
                }
            }
            return list;
        }

        public Urun BarkodaGoreGetir(string barkod)
        {
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT * FROM Urunler WHERE Barkod=@Barkod", conn);
                cmd.Parameters.AddWithValue("@Barkod", barkod);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Urun
                        {
                            Urun_Id = Convert.ToInt32(reader["Urun_Id"]),
                            Barkod = reader["Barkod"].ToString(),
                            Ad = reader["Ad"].ToString(),
                            Kategori = reader["Kategori"] != DBNull.Value ? reader["Kategori"].ToString() : null,
                            Adet = Convert.ToInt32(reader["Adet"]),
                            Alis_Fiyati = Convert.ToDecimal(reader["Alis_Fiyati"]),
                            Satis_Fiyati = Convert.ToDecimal(reader["Satis_Fiyati"]),
                            Kritik_Stok_Seviyesi = Convert.ToInt32(reader["Kritik_Stok_Seviyesi"])
                        };
                    }
                }
            }
            return null;
        }
    }
}
