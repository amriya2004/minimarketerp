using System.Data.SqlClient;

namespace MiniMarketERP.DataAccess
{
    public static class DbHelper
    {
        // Varsayılan bağlantı stringi
        public static string ConnectionString = @"Server=.\SQLEXPRESS01;Database=MiniMarketERP;Trusted_Connection=True;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
