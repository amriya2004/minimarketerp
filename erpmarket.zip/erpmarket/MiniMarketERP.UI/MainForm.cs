using System;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;

namespace MiniMarketERP.UI
{
    public partial class MainForm : Form
    {
        private Guna2Panel navPanel;
        private Guna2Panel contentPanel;
        private Guna2Button btnSatis, btnStok, btnMusteri, btnOdeme, btnTedarik, btnRapor, btnKapat;
        
        // Colors mapping exactly matching mockups
        private Color colorSatis = Color.FromArgb(255, 153, 204); // Mockup Pink
        private Color colorStok = Color.FromArgb(34, 139, 34);    // Mockup Green
        private Color colorMusteri = Color.FromArgb(173, 216, 230); // Mockup Light Blue
        private Color colorTedarik = Color.FromArgb(255, 178, 102); // Mockup Orange
        private Color colorOdeme = Color.FromArgb(32, 178, 170);   // Mockup Teal
        private Color colorRapor = Color.FromArgb(147, 112, 219); // Mockup Purple

        private Color darkBlueNav = Color.FromArgb(10, 10, 100);

        public MainForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Size = new Size(1100, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            
            Guna2DragControl dragControl = new Guna2DragControl();
            dragControl.TargetControl = this;

            navPanel = new Guna2Panel();
            navPanel.Dock = DockStyle.Top;
            navPanel.Height = 75;
            navPanel.BackColor = Color.Transparent;
            dragControl.TargetControl = navPanel;

            contentPanel = new Guna2Panel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.BackColor = Color.Transparent;

            this.Controls.Add(contentPanel);
            this.Controls.Add(navPanel);

            btnRapor = CreateNavButton("Raporlar");
            btnOdeme = CreateNavButton("Ödeme");
            btnTedarik = CreateNavButton("Tedarikçi İşlemleri");
            btnStok = CreateNavButton("Stok Yönetimi");
            btnMusteri = CreateNavButton("Müşteriler");
            btnSatis = CreateNavButton("SATIŞ YAP");
            
            btnKapat = new Guna2Button { 
                Text = "X", FillColor = Color.Red, ForeColor = Color.White, 
                Font = new Font("Segoe UI", 12, FontStyle.Bold), 
                Width = 45, Height = 45, BorderRadius = 20, Cursor = Cursors.Hand 
            };
            btnKapat.Click += (s, e) => Application.Exit();

            FlowLayoutPanel flp = new FlowLayoutPanel();
            flp.Dock = DockStyle.Fill;
            flp.BackColor = Color.Transparent;
            flp.Padding = new Padding(20, 15, 0, 0);
            flp.WrapContents = false;
            
            flp.Controls.Add(btnRapor);
            flp.Controls.Add(btnOdeme);
            flp.Controls.Add(btnTedarik);
            flp.Controls.Add(btnStok);
            flp.Controls.Add(btnMusteri);
            flp.Controls.Add(btnSatis);
            
            btnKapat.Margin = new Padding(30, 0, 0, 0);
            flp.Controls.Add(btnKapat);

            navPanel.Controls.Add(flp);

            btnSatis.Click += (s, e) => LoadView(new Views.SatisView(), colorSatis, btnSatis, Color.FromArgb(52, 152, 219), Color.Black);
            btnStok.Click += (s, e) => LoadView(new Views.StokView(), colorStok, btnStok, Color.White, Color.Green);
            btnMusteri.Click += (s, e) => LoadView(new Views.MusteriView(), colorMusteri, btnMusteri, Color.Gold, Color.Black);
            btnTedarik.Click += (s, e) => LoadView(new Views.TedarikView(), colorTedarik, btnTedarik, Color.Red, Color.White);
            btnOdeme.Click += (s, e) => LoadView(new Views.OdemeView(), colorOdeme, btnOdeme, Color.FromArgb(255, 153, 204), Color.Black);
            btnRapor.Click += (s, e) => LoadView(new Views.RaporView(), colorRapor, btnRapor, Color.LightYellow, Color.Black);

            this.Load += (s, e) => btnSatis.PerformClick();
        }

        private Guna2Button CreateNavButton(string text)
        {
            return new Guna2Button
            {
                Text = text,
                FillColor = darkBlueNav,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Width = 145,
                Height = 45,
                Margin = new Padding(0, 0, 10, 0),
                BorderRadius = 22,
                Cursor = Cursors.Hand,
                Animated = true
            };
        }

        private void LoadView(UserControl view, Color backColor, Guna2Button activeBtn, Color activeBtnColor, Color activeTextColor)
        {
            this.BackColor = backColor;

            Guna2Button[] btns = { btnSatis, btnStok, btnMusteri, btnOdeme, btnTedarik, btnRapor };
            foreach (var btn in btns)
            {
                btn.FillColor = darkBlueNav;
                btn.ForeColor = Color.White;
            }

            activeBtn.FillColor = activeBtnColor;
            activeBtn.ForeColor = activeTextColor;

            contentPanel.Controls.Clear();
            view.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(view);
        }
    }
}
