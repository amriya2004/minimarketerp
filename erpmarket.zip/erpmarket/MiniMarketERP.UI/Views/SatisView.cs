using System;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MiniMarketERP.Business;
using MiniMarketERP.Entities;

namespace MiniMarketERP.UI.Views
{
    public partial class SatisView : UserControl
    {
        private SatisManager _satisManager;
        private UrunManager _urunManager;
        
        private Guna2TextBox txtBarkod, txtSatisId, txtTutar, txtTarih, txtMusteriId, txtOdemeYontemi, txtSatisDurumu;
        private Guna2DataGridView dgvSepet;
        private Guna2Button btnSatisBaslat, btnEkle, btnSil, btnToplamHesapla, btnKaydet, btnIptalEt;
        private bool isSaleActive = false;

        public SatisView()
        {
            _satisManager = new SatisManager();
            _urunManager = new UrunManager();
            InitializeComponent();
            LoadSatisGecmisi();
        }

        private void InitializeComponent()
        {
            this.BackColor = Color.Transparent;

            // Buttons according to Mockup
            btnSatisBaslat = CreateActionButton("Satış Başlat", 30, 20);
            btnEkle = CreateActionButton("Ekle", 180, 20, 80);
            btnSil = CreateActionButton("Sil", 270, 20, 80);
            btnToplamHesapla = CreateActionButton("Toplam Hesapla", 360, 20, 140);
            btnKaydet = CreateActionButton("Kaydet", 510, 20, 140);
            btnIptalEt = CreateActionButton("İptal Et", 660, 20, 100);
            btnIptalEt.BorderThickness = 2;
            btnIptalEt.BorderColor = Color.Purple;

            // Extra invisible/unobtrusive barkod field at the very top right, as flowchart needs it
            Label lblBarkod = new Label { Text = "Barkod Okut:", Location = new Point(780, 30), Font = new Font("Segoe UI", 10, FontStyle.Bold | FontStyle.Italic), ForeColor = Color.Black, AutoSize = true };
            this.Controls.Add(lblBarkod);
            txtBarkod = new Guna2TextBox { Location = new Point(880, 20), Width = 150, Height = 36, BorderRadius = 18, Font = new Font("Segoe UI", 10), FillColor = Color.White };
            txtBarkod.KeyDown += TxtBarkod_KeyDown;
            this.Controls.Add(txtBarkod);

            // Left Column TextBoxes
            txtSatisId = CreateInput("Satış_id", 30, 100);
            txtTutar = CreateInput("Tutar", 30, 160);
            txtTarih = CreateInput("Tarih", 30, 220);

            // Right Column TextBoxes
            txtMusteriId = CreateInput("Müşteri_id", 400, 100);
            txtOdemeYontemi = CreateInput("Ödeme Yöntemi", 400, 160);
            txtSatisDurumu = CreateInput("Satış Durumu", 400, 220);

            dgvSepet = new Guna2DataGridView
            {
                Location = new Point(30, 310),
                Width = 1000,
                Height = 330,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                AllowUserToAddRows = false,
                ReadOnly = true,
                ThemeStyle = {
                    HeaderStyle = { BackColor = Color.LightGray, ForeColor = Color.Black, Font = new Font("Segoe UI", 10, FontStyle.Bold) },
                    RowsStyle = { Font = new Font("Segoe UI", 10), BackColor = Color.White },
                    AlternatingRowsStyle = { BackColor = Color.FromArgb(240, 240, 240) }
                },
                GridColor = Color.Black
            };

            this.Controls.Add(btnSatisBaslat);
            this.Controls.Add(btnEkle);
            this.Controls.Add(btnSil);
            this.Controls.Add(btnToplamHesapla);
            this.Controls.Add(btnKaydet);
            this.Controls.Add(btnIptalEt);
            this.Controls.Add(dgvSepet);

            btnSatisBaslat.Click += BtnSatisBaslat_Click;
            btnKaydet.Click += BtnKaydet_Click;
            btnIptalEt.Click += BtnIptalEt_Click;
            btnEkle.Click += BtnEkle_Click;
            btnSil.Click += BtnSil_Click;
            btnToplamHesapla.Click += (s, e) => { txtTutar.Text = _satisManager.ToplamHesapla().ToString("C2"); };
        }

        private Guna2Button CreateActionButton(string text, int x, int y, int width = 140)
        {
            return new Guna2Button
            {
                Text = text,
                FillColor = Color.White,
                ForeColor = Color.FromArgb(10, 10, 100),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(x, y),
                Width = width,
                Height = 45,
                BorderRadius = 22,
                Cursor = Cursors.Hand,
                Animated = true
            };
        }

        private Guna2TextBox CreateInput(string labelText, int x, int y)
        {
            Label lbl = new Label { Text = labelText, Location = new Point(x, y + 10), Font = new Font("Segoe UI", 10, FontStyle.Bold | FontStyle.Italic), ForeColor = Color.Black, AutoSize = true };
            this.Controls.Add(lbl);

            Guna2TextBox txt = new Guna2TextBox
            {
                Location = new Point(x + 130, y),
                Width = 220,
                Height = 36,
                BorderThickness = 0,
                BorderRadius = 18,
                Font = new Font("Segoe UI", 10),
                FillColor = Color.White
            };
            this.Controls.Add(txt);
            return txt;
        }

        private void LoadSatisGecmisi()
        {
            dgvSepet.DataSource = _satisManager.SatisListele();
            isSaleActive = false;
        }

        private void BtnSatisBaslat_Click(object sender, EventArgs e)
        {
            _satisManager.SatisBaslat();
            isSaleActive = true;
            SepetiGuncelle();
            txtSatisDurumu.Text = "Başladı";
            txtSatisId.Clear();
            txtTutar.Text = "0,00 ₺";
            txtTarih.Text = DateTime.Now.ToString("dd.MM.yyyy HH:mm");
            txtOdemeYontemi.Clear();
            txtMusteriId.Clear();
            txtBarkod.Focus();
        }

        private void BtnIptalEt_Click(object sender, EventArgs e)
        {
            _satisManager.SatisIptalEt();
            LoadSatisGecmisi();
            txtSatisDurumu.Text = "İptal Edildi";
        }

        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            if (!isSaleActive) return;

            try
            {
                int? musteriId = string.IsNullOrEmpty(txtMusteriId.Text) ? (int?)null : int.Parse(txtMusteriId.Text);
                int satisId = _satisManager.SatisTamamla(musteriId);
                txtSatisId.Text = satisId.ToString();
                txtTarih.Text = DateTime.Now.ToString("dd.MM.yyyy HH:mm");
                txtSatisDurumu.Text = "Tamamlandı";
                MessageBox.Show("Satış başarıyla tamamlandı. Satış No: " + satisId, "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _satisManager.SatisBaslat();
                LoadSatisGecmisi();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnEkle_Click(object sender, EventArgs e)
        {
            string barkod = txtBarkod.Text.Trim();
            UrunEkle(barkod);
        }

        private void TxtBarkod_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string barkod = txtBarkod.Text.Trim();
                UrunEkle(barkod);
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void UrunEkle(string barkod)
        {
            if (!isSaleActive)
            {
                MessageBox.Show("Lütfen önce Satış Başlat butonuna tıklayın.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!string.IsNullOrEmpty(barkod))
            {
                try
                {
                    var urun = _urunManager.BarkodaGoreGetir(barkod);
                    if (urun != null)
                    {
                        try
                        {
                            _satisManager.SepeteUrunEkle(urun, 1);
                        }
                        catch (Exception ex)
                        {
                            // Stok yetersizse flowchart kuralı: Tedarikçiye ürün talebi bulun
                            MessageBox.Show(ex.Message + "\nSistem otomatik olarak tedarik talebi oluşturmalıdır.", "Stok Yetersiz", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            // Burada Tedarik talebi loglanabilir (ileride)
                        }
                        SepetiGuncelle();
                        txtTutar.Text = _satisManager.ToplamHesapla().ToString("C2");
                    }
                    else
                    {
                        MessageBox.Show("Ürün bulunamadı!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            txtBarkod.Clear();
            txtBarkod.Focus();
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
            if (!isSaleActive) return;

            if (dgvSepet.CurrentRow != null)
            {
                int urunId = Convert.ToInt32(dgvSepet.CurrentRow.Cells["Urun_Id"].Value);
                _satisManager.UrunCikar(urunId);
                SepetiGuncelle();
                txtTutar.Text = _satisManager.ToplamHesapla().ToString("C2");
            }
            else
            {
                MessageBox.Show("Lütfen silinecek ürünü seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void SepetiGuncelle()
        {
            dgvSepet.DataSource = null;
            dgvSepet.DataSource = _satisManager.SepetiGetir();
        }
    }
}
