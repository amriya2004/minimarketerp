using System;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MiniMarketERP.Business;
using MiniMarketERP.Entities;

namespace MiniMarketERP.UI.Views
{
    public partial class MusteriView : UserControl
    {
        private MusteriManager _musteriManager;
        private Guna2DataGridView dgvMusteri;
        private Guna2TextBox txtAd, txtSoyad, txtTelefon, txtEposta, txtBorc;
        private Guna2Button btnKaydet, btnGuncelle, btnSil, btnListele, btnGoruntule, btnBorcSorgula;

        public MusteriView()
        {
            _musteriManager = new MusteriManager();
            InitializeComponent();
            LoadData();
        }

        private void InitializeComponent()
        {
            this.BackColor = Color.Transparent;

            btnKaydet = CreateActionButton("Kaydet", 30, 20);
            btnGuncelle = CreateActionButton("Güncelle", 180, 20);
            btnSil = CreateActionButton("Sil", 330, 20);
            btnListele = CreateActionButton("Listele", 480, 20);
            btnGoruntule = CreateActionButton("Görüntüle", 630, 20);
            btnBorcSorgula = CreateActionButton("Borç Sorgula", 780, 20);

            txtAd = CreateInput("Müşteri Adı", 30, 90);
            txtSoyad = CreateInput("Müşteri Soyadı", 30, 140);
            txtTelefon = CreateInput("Telefon Numarası", 30, 190);
            txtEposta = CreateInput("E-Posta", 30, 240);
            txtBorc = CreateInput("Güncel Borç", 30, 290);

            dgvMusteri = new Guna2DataGridView
            {
                Location = new Point(400, 90),
                Width = 630,
                Height = 550,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ThemeStyle = {
                    HeaderStyle = { BackColor = Color.LightGray, ForeColor = Color.Black, Font = new Font("Segoe UI", 10, FontStyle.Bold) },
                    RowsStyle = { Font = new Font("Segoe UI", 10), BackColor = Color.White },
                    AlternatingRowsStyle = { BackColor = Color.FromArgb(240, 240, 240) }
                },
                GridColor = Color.Black
            };

            this.Controls.Add(btnKaydet);
            this.Controls.Add(btnGuncelle);
            this.Controls.Add(btnSil);
            this.Controls.Add(btnListele);
            this.Controls.Add(btnGoruntule);
            this.Controls.Add(btnBorcSorgula);
            this.Controls.Add(dgvMusteri);

            btnKaydet.Click += BtnKaydet_Click;
            btnGuncelle.Click += BtnGuncelle_Click;
            btnSil.Click += BtnSil_Click;
            btnGoruntule.Click += BtnGoruntule_Click;
            btnListele.Click += (s, e) => LoadData();
            btnBorcSorgula.Click += BtnBorcSorgula_Click;
        }

        private Guna2Button CreateActionButton(string text, int x, int y, int width = 130)
        {
            return new Guna2Button
            {
                Text = text,
                FillColor = Color.White,
                ForeColor = Color.FromArgb(10, 10, 100),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(x, y),
                Width = width,
                Height = 45,
                BorderRadius = 22,
                Cursor = Cursors.Hand,
                Animated = true
            };
        }

        private Guna2TextBox CreateInput(string labelText, int x, int y)
        {
            Label lbl = new Label { Text = labelText, Location = new Point(x, y + 10), Font = new Font("Segoe UI", 10, FontStyle.Bold | FontStyle.Italic), ForeColor = Color.Black, AutoSize = true };
            this.Controls.Add(lbl);

            Guna2TextBox txt = new Guna2TextBox
            {
                Location = new Point(x + 140, y),
                Width = 220,
                Height = 36,
                BorderThickness = 0,
                BorderRadius = 18,
                Font = new Font("Segoe UI", 10),
                FillColor = Color.White
            };
            this.Controls.Add(txt);
            return txt;
        }

        private void LoadData()
        {
            dgvMusteri.DataSource = _musteriManager.MusteriListele();
        }

        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                var m = new Musteri
                {
                    Ad = txtAd.Text,
                    Soyad = txtSoyad.Text,
                    Telefon = txtTelefon.Text,
                    Eposta = txtEposta.Text,
                    Guncel_Borc = 0
                };
                _musteriManager.MusteriEkle(m);
                MessageBox.Show("Müşteri Eklendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnGuncelle_Click(object sender, EventArgs e)
        {
            if (dgvMusteri.CurrentRow != null)
            {
                try
                {
                    int id = (int)dgvMusteri.CurrentRow.Cells["Musteri_Id"].Value;
                    var m = new Musteri
                    {
                        Musteri_Id = id,
                        Ad = txtAd.Text,
                        Soyad = txtSoyad.Text,
                        Telefon = txtTelefon.Text,
                        Eposta = txtEposta.Text,
                        Guncel_Borc = decimal.Parse(string.IsNullOrWhiteSpace(txtBorc.Text) ? "0" : txtBorc.Text.Replace("₺", "").Trim())
                    };
                    _musteriManager.MusteriGuncelle(m);
                    MessageBox.Show("Müşteri Güncellendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Lütfen tablodan güncellenecek müşteriyi seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
            if (dgvMusteri.CurrentRow != null)
            {
                try
                {
                    int id = (int)dgvMusteri.CurrentRow.Cells["Musteri_Id"].Value;
                    var result = MessageBox.Show("Müşteriyi silmek istediğinize emin misiniz?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        _musteriManager.MusteriSil(id);
                        MessageBox.Show("Müşteri Silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadData();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: Bu müşteri ile ilişkili kayıtlar olabilir. " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Lütfen tablodan silinecek müşteriyi seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnGoruntule_Click(object sender, EventArgs e)
        {
            if (dgvMusteri.CurrentRow != null)
            {
                txtAd.Text = dgvMusteri.CurrentRow.Cells["Ad"].Value?.ToString();
                txtSoyad.Text = dgvMusteri.CurrentRow.Cells["Soyad"].Value?.ToString();
                txtTelefon.Text = dgvMusteri.CurrentRow.Cells["Telefon"].Value?.ToString();
                txtEposta.Text = dgvMusteri.CurrentRow.Cells["Eposta"].Value?.ToString();
                txtBorc.Text = dgvMusteri.CurrentRow.Cells["Guncel_Borc"].Value?.ToString();
            }
            else
            {
                MessageBox.Show("Lütfen tablodan görüntülenecek müşteriyi seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnBorcSorgula_Click(object sender, EventArgs e)
        {
            if (dgvMusteri.CurrentRow != null)
            {
                int id = (int)dgvMusteri.CurrentRow.Cells["Musteri_Id"].Value;
                decimal borc = _musteriManager.BorcSorgula(id);
                txtBorc.Text = borc.ToString("C2");
                MessageBox.Show($"Müşterinin Güncel Borcu: {borc:C2}", "Borç Bilgisi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Lütfen tablodan bir müşteri seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
