using System;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MiniMarketERP.Business;
using MiniMarketERP.Entities;

namespace MiniMarketERP.UI.Views
{
    public partial class TedarikView : UserControl
    {
        private TedarikManager _tedarikManager;
        private Guna2DataGridView dgvTedarik;
        private Guna2TextBox txtAlimId, txtTedarikciId, txtUrunId, txtAlimTarihi, txtMiktar, txtBirimFiyat;
        private Guna2Button btnKaydet, btnGuncelle, btnSil, btnListele, btnAlimKaydi, btnBorcDurumu;

        public TedarikView()
        {
            _tedarikManager = new TedarikManager();
            InitializeComponent();
            LoadData();
        }

        private void InitializeComponent()
        {
            this.BackColor = Color.Transparent;

            btnKaydet = CreateActionButton("Kaydet", 30, 20);
            btnGuncelle = CreateActionButton("Güncelle", 180, 20);
            btnSil = CreateActionButton("Sil", 330, 20);
            btnListele = CreateActionButton("Listele", 480, 20);
            btnAlimKaydi = CreateActionButton("Ürün Alım Kaydı", 630, 20, 160);
            btnBorcDurumu = CreateActionButton("Borç Durumu Görüntüle", 800, 20, 180);

            // Left Column
            txtAlimId = CreateInput("Alım_id", 30, 90);
            txtTedarikciId = CreateInput("Tedarikçi_id", 30, 140);
            txtUrunId = CreateInput("Ürün_id", 30, 190);

            // Right Column
            txtAlimTarihi = CreateInput("Alım_Tarihi", 400, 90);
            txtMiktar = CreateInput("Miktar", 400, 140);
            txtBirimFiyat = CreateInput("Birim_Alış_Fiyatı", 400, 190);

            dgvTedarik = new Guna2DataGridView
            {
                Location = new Point(30, 310),
                Width = 1000,
                Height = 330,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ThemeStyle = {
                    HeaderStyle = { BackColor = Color.LightGray, ForeColor = Color.Black, Font = new Font("Segoe UI", 10, FontStyle.Bold) },
                    RowsStyle = { Font = new Font("Segoe UI", 10), BackColor = Color.White },
                    AlternatingRowsStyle = { BackColor = Color.FromArgb(240, 240, 240) }
                },
                GridColor = Color.Black
            };

            this.Controls.Add(btnKaydet);
            this.Controls.Add(btnGuncelle);
            this.Controls.Add(btnSil);
            this.Controls.Add(btnListele);
            this.Controls.Add(btnAlimKaydi);
            this.Controls.Add(btnBorcDurumu);
            this.Controls.Add(dgvTedarik);

            btnKaydet.Click += BtnKaydet_Click;
            btnGuncelle.Click += BtnGuncelle_Click;
            btnSil.Click += BtnSil_Click;
            btnListele.Click += (s, e) => LoadData();
            btnAlimKaydi.Click += BtnAlimKaydet_Click;
            btnBorcDurumu.Click += BtnBorcDurumu_Click;
            
            dgvTedarik.CellClick += DgvTedarik_CellClick;
        }

        private Guna2Button CreateActionButton(string text, int x, int y, int width = 130)
        {
            return new Guna2Button
            {
                Text = text,
                FillColor = Color.White,
                ForeColor = Color.FromArgb(10, 10, 100),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(x, y),
                Width = width,
                Height = 45,
                BorderRadius = 22,
                Cursor = Cursors.Hand,
                Animated = true
            };
        }

        private Guna2TextBox CreateInput(string labelText, int x, int y)
        {
            Label lbl = new Label { Text = labelText, Location = new Point(x, y + 10), Font = new Font("Segoe UI", 10, FontStyle.Bold | FontStyle.Italic), ForeColor = Color.Black, AutoSize = true };
            this.Controls.Add(lbl);

            Guna2TextBox txt = new Guna2TextBox
            {
                Location = new Point(x + 150, y),
                Width = 220,
                Height = 36,
                BorderThickness = 0,
                BorderRadius = 18,
                Font = new Font("Segoe UI", 10),
                FillColor = Color.White
            };
            this.Controls.Add(txt);
            return txt;
        }

        private void LoadData()
        {
            dgvTedarik.DataSource = _tedarikManager.AlimListele();
        }

        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            BtnAlimKaydet_Click(sender, e);
        }

        private void BtnAlimKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                var alim = new Alim
                {
                    Tedarikci_Id = int.Parse(string.IsNullOrWhiteSpace(txtTedarikciId.Text) ? "0" : txtTedarikciId.Text),
                    Urun_Id = int.Parse(string.IsNullOrWhiteSpace(txtUrunId.Text) ? "0" : txtUrunId.Text),
                    Miktar = int.Parse(string.IsNullOrWhiteSpace(txtMiktar.Text) ? "0" : txtMiktar.Text),
                    Birim_Alis_Fiyati = decimal.Parse(string.IsNullOrWhiteSpace(txtBirimFiyat.Text) ? "0" : txtBirimFiyat.Text),
                    Alim_Tarihi = DateTime.Now
                };
                
                _tedarikManager.UrunAlimKaydi(alim);
                MessageBox.Show("Alım kaydedildi ve stok güncellendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnGuncelle_Click(object sender, EventArgs e)
        {
            if (dgvTedarik.CurrentRow != null)
            {
                try
                {
                    int id = (int)dgvTedarik.CurrentRow.Cells["Alim_Id"].Value;
                    var alim = new Alim
                    {
                        Alim_Id = id,
                        Tedarikci_Id = int.Parse(string.IsNullOrWhiteSpace(txtTedarikciId.Text) ? "0" : txtTedarikciId.Text),
                        Urun_Id = int.Parse(string.IsNullOrWhiteSpace(txtUrunId.Text) ? "0" : txtUrunId.Text),
                        Miktar = int.Parse(string.IsNullOrWhiteSpace(txtMiktar.Text) ? "0" : txtMiktar.Text),
                        Birim_Alis_Fiyati = decimal.Parse(string.IsNullOrWhiteSpace(txtBirimFiyat.Text) ? "0" : txtBirimFiyat.Text.Replace("₺", "").Trim()),
                        Alim_Tarihi = DateTime.Parse(txtAlimTarihi.Text)
                    };
                    _tedarikManager.AlimGuncelle(alim);
                    MessageBox.Show("Alım Güncellendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Lütfen tablodan güncellenecek alımı seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
            if (dgvTedarik.CurrentRow != null)
            {
                try
                {
                    int id = (int)dgvTedarik.CurrentRow.Cells["Alim_Id"].Value;
                    var result = MessageBox.Show("Alımı silmek istediğinize emin misiniz?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        _tedarikManager.AlimSil(id);
                        MessageBox.Show("Alım Silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadData();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Lütfen tablodan silinecek alımı seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnBorcDurumu_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtTedarikciId.Text))
            {
                int tedarikciId = int.Parse(txtTedarikciId.Text);
                decimal borc = _tedarikManager.BorcSorgula(tedarikciId);
                MessageBox.Show($"Tedarikçi No {tedarikciId} için toplam borç: {borc:C2}", "Borç Durumu", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Lütfen Tedarikçi_id girin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void DgvTedarik_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvTedarik.CurrentRow != null)
            {
                txtAlimId.Text = dgvTedarik.CurrentRow.Cells["Alim_Id"].Value?.ToString();
                txtTedarikciId.Text = dgvTedarik.CurrentRow.Cells["Tedarikci_Id"].Value?.ToString();
                txtUrunId.Text = dgvTedarik.CurrentRow.Cells["Urun_Id"].Value?.ToString();
                txtAlimTarihi.Text = dgvTedarik.CurrentRow.Cells["Alim_Tarihi"].Value?.ToString();
                txtMiktar.Text = dgvTedarik.CurrentRow.Cells["Miktar"].Value?.ToString();
                txtBirimFiyat.Text = dgvTedarik.CurrentRow.Cells["Birim_Alis_Fiyati"].Value?.ToString();
            }
        }
    }
}
