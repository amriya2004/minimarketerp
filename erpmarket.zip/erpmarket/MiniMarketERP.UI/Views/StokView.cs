using System;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MiniMarketERP.Business;
using MiniMarketERP.Entities;

namespace MiniMarketERP.UI.Views
{
    public partial class StokView : UserControl
    {
        private UrunManager _urunManager;
        private Guna2DataGridView dgvStok;
        private Guna2TextBox txtUrunId, txtBarkod, txtAd, txtKategori, txtAdet, txtAlis, txtSatis, txtKritik;
        private Guna2Button btnKaydet, btnGuncelle, btnSil, btnListele, btnStokKontrol, btnBarkodOlustur;

        public StokView()
        {
            _urunManager = new UrunManager();
            InitializeComponent();
            LoadData();
        }

        private void InitializeComponent()
        {
            this.BackColor = Color.Transparent;

            btnKaydet = CreateActionButton("Kaydet", 30, 20);
            btnGuncelle = CreateActionButton("Güncelle", 180, 20);
            btnSil = CreateActionButton("Sil", 330, 20);
            btnListele = CreateActionButton("Listele", 480, 20);
            btnStokKontrol = CreateActionButton("Stok Kontrolü", 630, 20);
            btnBarkodOlustur = CreateActionButton("Barkod Oluştur", 780, 20);

            // Left Column
            txtUrunId = CreateInput("Ürün_id", 30, 90);
            txtBarkod = CreateInput("Barkod", 30, 140);
            txtAd = CreateInput("Ad", 30, 190);
            txtKategori = CreateInput("Kategori", 30, 240);

            // Right Column
            txtAdet = CreateInput("Adet", 400, 90);
            txtAlis = CreateInput("Alış Fiyatı", 400, 140);
            txtSatis = CreateInput("Satış Fiyatı", 400, 190);
            txtKritik = CreateInput("Stok_Kontrolü", 400, 240);

            dgvStok = new Guna2DataGridView
            {
                Location = new Point(30, 310),
                Width = 1000,
                Height = 330,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ThemeStyle = {
                    HeaderStyle = { BackColor = Color.LightGray, ForeColor = Color.Black, Font = new Font("Segoe UI", 10, FontStyle.Bold) },
                    RowsStyle = { Font = new Font("Segoe UI", 10), BackColor = Color.White },
                    AlternatingRowsStyle = { BackColor = Color.FromArgb(240, 240, 240) }
                },
                GridColor = Color.Black
            };

            this.Controls.Add(btnKaydet);
            this.Controls.Add(btnGuncelle);
            this.Controls.Add(btnSil);
            this.Controls.Add(btnListele);
            this.Controls.Add(btnStokKontrol);
            this.Controls.Add(btnBarkodOlustur);
            this.Controls.Add(dgvStok);

            btnKaydet.Click += BtnKaydet_Click;
            btnGuncelle.Click += BtnGuncelle_Click;
            btnSil.Click += BtnSil_Click;
            btnListele.Click += (s, e) => LoadData();
            btnStokKontrol.Click += BtnStokKontrol_Click;
            btnBarkodOlustur.Click += BtnBarkodOlustur_Click;
            
            dgvStok.CellClick += DgvStok_CellClick;
        }

        private Guna2Button CreateActionButton(string text, int x, int y, int width = 130)
        {
            return new Guna2Button
            {
                Text = text,
                FillColor = Color.White,
                ForeColor = Color.FromArgb(10, 10, 100),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(x, y),
                Width = width,
                Height = 45,
                BorderRadius = 22,
                Cursor = Cursors.Hand,
                Animated = true
            };
        }

        private Guna2TextBox CreateInput(string labelText, int x, int y)
        {
            Label lbl = new Label { Text = labelText, Location = new Point(x, y + 10), Font = new Font("Segoe UI", 10, FontStyle.Bold | FontStyle.Italic), ForeColor = Color.White, AutoSize = true };
            this.Controls.Add(lbl);

            Guna2TextBox txt = new Guna2TextBox
            {
                Location = new Point(x + 130, y),
                Width = 220,
                Height = 36,
                BorderThickness = 0,
                BorderRadius = 18,
                Font = new Font("Segoe UI", 10),
                FillColor = Color.White
            };
            this.Controls.Add(txt);
            return txt;
        }

        private void LoadData()
        {
            dgvStok.DataSource = _urunManager.StokListele();
        }

        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                var urun = new Urun
                {
                    Barkod = txtBarkod.Text,
                    Ad = txtAd.Text,
                    Kategori = txtKategori.Text,
                    Adet = int.Parse(string.IsNullOrWhiteSpace(txtAdet.Text) ? "0" : txtAdet.Text),
                    Alis_Fiyati = decimal.Parse(string.IsNullOrWhiteSpace(txtAlis.Text) ? "0" : txtAlis.Text),
                    Satis_Fiyati = decimal.Parse(string.IsNullOrWhiteSpace(txtSatis.Text) ? "0" : txtSatis.Text),
                    Kritik_Stok_Seviyesi = int.Parse(string.IsNullOrWhiteSpace(txtKritik.Text) ? "0" : txtKritik.Text)
                };
                _urunManager.UrunEkle(urun);
                MessageBox.Show("Ürün Eklendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnStokKontrol_Click(object sender, EventArgs e)
        {
            var liste = _urunManager.KritikStokKontrol();
            dgvStok.DataSource = liste;
            if (liste.Count > 0)
                MessageBox.Show("Dikkat! Kritik seviyede ürünler var.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
                MessageBox.Show("Kritik seviyede ürün yok.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnGuncelle_Click(object sender, EventArgs e)
        {
            if (dgvStok.CurrentRow != null)
            {
                try
                {
                    int id = (int)dgvStok.CurrentRow.Cells["Urun_Id"].Value;
                    var urun = new Urun
                    {
                        Urun_Id = id,
                        Barkod = txtBarkod.Text,
                        Ad = txtAd.Text,
                        Kategori = txtKategori.Text,
                        Adet = int.Parse(string.IsNullOrWhiteSpace(txtAdet.Text) ? "0" : txtAdet.Text),
                        Alis_Fiyati = decimal.Parse(string.IsNullOrWhiteSpace(txtAlis.Text) ? "0" : txtAlis.Text.Replace("₺", "").Trim()),
                        Satis_Fiyati = decimal.Parse(string.IsNullOrWhiteSpace(txtSatis.Text) ? "0" : txtSatis.Text.Replace("₺", "").Trim()),
                        Kritik_Stok_Seviyesi = int.Parse(string.IsNullOrWhiteSpace(txtKritik.Text) ? "0" : txtKritik.Text)
                    };
                    _urunManager.UrunGuncelle(urun);
                    MessageBox.Show("Ürün Güncellendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Lütfen tablodan güncellenecek ürünü seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnSil_Click(object sender, EventArgs e)
        {
            if (dgvStok.CurrentRow != null)
            {
                try
                {
                    int id = (int)dgvStok.CurrentRow.Cells["Urun_Id"].Value;
                    var result = MessageBox.Show("Ürünü silmek istediğinize emin misiniz?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        _urunManager.UrunSil(id);
                        MessageBox.Show("Ürün Silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadData();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata: Bu ürün ile ilişkili satış veya alım kayıtları olabilir. " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Lütfen tablodan silinecek ürünü seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnBarkodOlustur_Click(object sender, EventArgs e)
        {
            txtBarkod.Text = _urunManager.BarkodOlustur();
        }

        private void DgvStok_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvStok.CurrentRow != null)
            {
                txtUrunId.Text = dgvStok.CurrentRow.Cells["Urun_Id"].Value?.ToString();
                txtBarkod.Text = dgvStok.CurrentRow.Cells["Barkod"].Value?.ToString();
                txtAd.Text = dgvStok.CurrentRow.Cells["Ad"].Value?.ToString();
                txtKategori.Text = dgvStok.CurrentRow.Cells["Kategori"].Value?.ToString();
                txtAdet.Text = dgvStok.CurrentRow.Cells["Adet"].Value?.ToString();
                txtAlis.Text = dgvStok.CurrentRow.Cells["Alis_Fiyati"].Value?.ToString();
                txtSatis.Text = dgvStok.CurrentRow.Cells["Satis_Fiyati"].Value?.ToString();
                txtKritik.Text = dgvStok.CurrentRow.Cells["Kritik_Stok_Seviyesi"].Value?.ToString();
            }
        }
    }
}
