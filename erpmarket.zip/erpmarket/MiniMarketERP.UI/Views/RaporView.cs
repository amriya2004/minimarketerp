using System;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MiniMarketERP.Business;

namespace MiniMarketERP.UI.Views
{
    public partial class RaporView : UserControl
    {
        private RaporManager _raporManager;
        private Guna2DataGridView dgvRapor;
        private Guna2Button btnGunlukCiro, btnEnCokSatan, btnStokDurumu, btnKarZarar, btnSatisRaporu;

        public RaporView()
        {
            _raporManager = new RaporManager();
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.BackColor = Color.Transparent;

            btnGunlukCiro = CreateActionButton("Günlük Ciro Raporu", 30, 20);
            btnEnCokSatan = CreateActionButton("En Çok Satan Ürünler", 190, 20);
            btnStokDurumu = CreateActionButton("Stok Durumu Raporu", 350, 20);
            btnKarZarar = CreateActionButton("Kar-Zarar Hesapla", 510, 20);
            btnSatisRaporu = CreateActionButton("Satış Raporu Filtrele", 670, 20);

            dgvRapor = new Guna2DataGridView
            {
                Location = new Point(30, 90),
                Width = 1000,
                Height = 550,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ThemeStyle = {
                    HeaderStyle = { BackColor = Color.LightGray, ForeColor = Color.Black, Font = new Font("Segoe UI", 10, FontStyle.Bold) },
                    RowsStyle = { Font = new Font("Segoe UI", 10), BackColor = Color.White },
                    AlternatingRowsStyle = { BackColor = Color.FromArgb(240, 240, 240) }
                },
                GridColor = Color.Black
            };

            this.Controls.Add(btnGunlukCiro);
            this.Controls.Add(btnEnCokSatan);
            this.Controls.Add(btnStokDurumu);
            this.Controls.Add(btnKarZarar);
            this.Controls.Add(btnSatisRaporu);
            this.Controls.Add(dgvRapor);

            btnGunlukCiro.Click += BtnGunlukCiro_Click;
            btnEnCokSatan.Click += BtnEnCokSatan_Click;
            btnStokDurumu.Click += BtnStokDurumu_Click;
            btnKarZarar.Click += BtnKarZarar_Click;
            btnSatisRaporu.Click += BtnSatisRaporu_Click;
        }

        private Guna2Button CreateActionButton(string text, int x, int y, int width = 140)
        {
            return new Guna2Button
            {
                Text = text,
                FillColor = Color.White,
                ForeColor = Color.FromArgb(10, 10, 100),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(x, y),
                Width = width,
                Height = 45,
                BorderRadius = 22,
                Cursor = Cursors.Hand,
                Animated = true
            };
        }

        private void BtnGunlukCiro_Click(object sender, EventArgs e)
        {
            dgvRapor.DataSource = _raporManager.GunlukCiroRaporu(DateTime.Now);
        }

        private void BtnEnCokSatan_Click(object sender, EventArgs e)
        {
            dgvRapor.DataSource = _raporManager.EnCokSatanUrunler();
        }

        private void BtnStokDurumu_Click(object sender, EventArgs e)
        {
            dgvRapor.DataSource = _raporManager.StokDurumRaporu();
        }

        private void BtnKarZarar_Click(object sender, EventArgs e)
        {
            dgvRapor.DataSource = _raporManager.KarZararRaporu();
        }

        private void BtnSatisRaporu_Click(object sender, EventArgs e)
        {
            // Basit bir filtreleme, form açmak yerine son 30 günü filtreleyelim (mockup gereği basitlik)
            DateTime baslangic = DateTime.Now.AddDays(-30);
            DateTime bitis = DateTime.Now;
            dgvRapor.DataSource = _raporManager.SatisRaporuFiltrele(baslangic, bitis);
            MessageBox.Show("Son 30 günlük satış raporu listelendi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
