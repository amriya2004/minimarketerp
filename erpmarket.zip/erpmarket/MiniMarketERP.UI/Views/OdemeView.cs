using System;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MiniMarketERP.Business;
using MiniMarketERP.Entities;

namespace MiniMarketERP.UI.Views
{
    public partial class OdemeView : UserControl
    {
        private OdemeManager _odemeManager;
        private Guna2DataGridView dgvOdeme;
        private Guna2TextBox txtOdemeId, txtOdemeTipi, txtSatisId, txtTutar, txtTarih;
        private Guna2Button btnKaydet, btnNakitOdeme, btnKartOdeme, btnIadeIslemi, btnFisOlustur;

        public OdemeView()
        {
            _odemeManager = new OdemeManager();
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            dgvOdeme.DataSource = _odemeManager.OdemeListele();
        }

        private void InitializeComponent()
        {
            this.BackColor = Color.Transparent;

            btnKaydet = CreateActionButton("Kaydet", 30, 20);
            btnNakitOdeme = CreateActionButton("Nakit Ödeme", 180, 20);
            btnKartOdeme = CreateActionButton("Kart Ödeme", 330, 20);
            btnIadeIslemi = CreateActionButton("İade İşlemi", 480, 20);
            btnFisOlustur = CreateActionButton("Fiş Oluştur", 630, 20);

            // Left Column
            txtOdemeId = CreateInput("Ödeme_id", 30, 90);
            txtOdemeTipi = CreateInput("Ödeme Tipi", 30, 140);
            txtSatisId = CreateInput("Satış_id", 30, 190);
            txtTutar = CreateInput("Tutar", 30, 240);
            txtTarih = CreateInput("Tarih", 30, 290);

            dgvOdeme = new Guna2DataGridView
            {
                Location = new Point(400, 90),
                Width = 630,
                Height = 550,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ThemeStyle = {
                    HeaderStyle = { BackColor = Color.LightGray, ForeColor = Color.Black, Font = new Font("Segoe UI", 10, FontStyle.Bold) },
                    RowsStyle = { Font = new Font("Segoe UI", 10), BackColor = Color.White },
                    AlternatingRowsStyle = { BackColor = Color.FromArgb(240, 240, 240) }
                },
                GridColor = Color.Black
            };

            this.Controls.Add(btnKaydet);
            this.Controls.Add(btnNakitOdeme);
            this.Controls.Add(btnKartOdeme);
            this.Controls.Add(btnIadeIslemi);
            this.Controls.Add(btnFisOlustur);
            this.Controls.Add(dgvOdeme);

            btnKaydet.Click += BtnKaydet_Click;
            btnNakitOdeme.Click += (s, e) => { txtOdemeTipi.Text = "Nakit"; };
            btnKartOdeme.Click += (s, e) => { txtOdemeTipi.Text = "Kart"; };
            btnIadeIslemi.Click += BtnIadeIslemi_Click;
            btnFisOlustur.Click += BtnFisOlustur_Click;
            
            dgvOdeme.CellClick += DgvOdeme_CellClick;
        }

        private Guna2Button CreateActionButton(string text, int x, int y, int width = 130)
        {
            return new Guna2Button
            {
                Text = text,
                FillColor = Color.White,
                ForeColor = Color.FromArgb(10, 10, 100),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(x, y),
                Width = width,
                Height = 45,
                BorderRadius = 22,
                Cursor = Cursors.Hand,
                Animated = true
            };
        }

        private Guna2TextBox CreateInput(string labelText, int x, int y)
        {
            Label lbl = new Label { Text = labelText, Location = new Point(x, y + 10), Font = new Font("Segoe UI", 10, FontStyle.Bold | FontStyle.Italic), ForeColor = Color.White, AutoSize = true };
            this.Controls.Add(lbl);

            Guna2TextBox txt = new Guna2TextBox
            {
                Location = new Point(x + 130, y),
                Width = 220,
                Height = 36,
                BorderThickness = 0,
                BorderRadius = 18,
                Font = new Font("Segoe UI", 10),
                FillColor = Color.White
            };
            this.Controls.Add(txt);
            return txt;
        }

        private void BtnKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                var odeme = new Odeme
                {
                    Musteri_Id = null, // Mockup does not have Musteri_id for Odeme, assuming anonymous or handled via Satis
                    Tutar = decimal.Parse(string.IsNullOrWhiteSpace(txtTutar.Text) ? "0" : txtTutar.Text),
                    OdemeTipi = txtOdemeTipi.Text,
                    Tarih = DateTime.Now
                };
                
                _odemeManager.OdemeAl(odeme);
                txtTarih.Text = DateTime.Now.ToString("dd.MM.yyyy HH:mm");
                MessageBox.Show("Ödeme başarıyla alındı.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnIadeIslemi_Click(object sender, EventArgs e)
        {
            try
            {
                var odeme = new Odeme
                {
                    Musteri_Id = null, // İade için mockup alanlarında Müşteri yoksa null veya Satis_Id den bulunabilir
                    Tutar = decimal.Parse(string.IsNullOrWhiteSpace(txtTutar.Text) ? "0" : txtTutar.Text.Replace("₺", "").Trim()),
                    OdemeTipi = txtOdemeTipi.Text,
                    Tarih = DateTime.Now
                };

                _odemeManager.IadeIslemi(odeme);
                MessageBox.Show("İade işlemi başarıyla gerçekleştirildi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnFisOlustur_Click(object sender, EventArgs e)
        {
            if (dgvOdeme.CurrentRow != null)
            {
                int odemeId = (int)dgvOdeme.CurrentRow.Cells["Odeme_Id"].Value;
                string fis = _odemeManager.FisOlustur(odemeId);
                MessageBox.Show(fis, "Fiş", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Lütfen tablodan bir ödeme seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void DgvOdeme_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvOdeme.CurrentRow != null)
            {
                txtOdemeId.Text = dgvOdeme.CurrentRow.Cells["Odeme_Id"].Value?.ToString();
                txtOdemeTipi.Text = dgvOdeme.CurrentRow.Cells["OdemeTipi"].Value?.ToString();
                txtSatisId.Text = dgvOdeme.CurrentRow.Cells["Satis_Id"].Value?.ToString();
                txtTutar.Text = dgvOdeme.CurrentRow.Cells["Tutar"].Value?.ToString();
                txtTarih.Text = dgvOdeme.CurrentRow.Cells["Tarih"].Value?.ToString();
            }
        }
    }
}
