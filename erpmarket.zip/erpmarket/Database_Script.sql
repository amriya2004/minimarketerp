USE [master]
GO

CREATE DATABASE [MiniMarketERP]
GO

USE [MiniMarketERP]
GO

CREATE TABLE [Urunler] (
    [Urun_Id] INT IDENTITY(1,1) PRIMARY KEY,
    [Barkod] NVARCHAR(50) NOT NULL UNIQUE,
    [Ad] NVARCHAR(100) NOT NULL,
    [Kategori] NVARCHAR(50) NULL,
    [Adet] INT NOT NULL DEFAULT 0,
    [Alis_Fiyati] DECIMAL(18,2) NOT NULL,
    [Satis_Fiyati] DECIMAL(18,2) NOT NULL,
    [Kritik_Stok_Seviyesi] INT NOT NULL DEFAULT 10
)
GO

CREATE TABLE [Musteriler] (
    [Musteri_Id] INT IDENTITY(1,1) PRIMARY KEY,
    [Ad] NVARCHAR(50) NOT NULL,
    [Soyad] NVARCHAR(50) NOT NULL,
    [Telefon] NVARCHAR(20) NULL,
    [Eposta] NVARCHAR(100) NULL,
    [Guncel_Borc] DECIMAL(18,2) NOT NULL DEFAULT 0
)
GO

CREATE TABLE [Satislar] (
    [Satis_Id] INT IDENTITY(1,1) PRIMARY KEY,
    [Musteri_Id] INT NULL FOREIGN KEY REFERENCES [Musteriler]([Musteri_Id]),
    [Tutar] DECIMAL(18,2) NOT NULL,
    [Tarih] DATETIME NOT NULL DEFAULT GETDATE(),
    [Satis_Durumu] NVARCHAR(20) NOT NULL -- Tamamlandı, İptal, vs.
)
GO

CREATE TABLE [SatisDetaylari] (
    [SatisDetay_Id] INT IDENTITY(1,1) PRIMARY KEY,
    [Satis_Id] INT NOT NULL FOREIGN KEY REFERENCES [Satislar]([Satis_Id]),
    [Urun_Id] INT NOT NULL FOREIGN KEY REFERENCES [Urunler]([Urun_Id]),
    [Miktar] INT NOT NULL,
    [BirimFiyat] DECIMAL(18,2) NOT NULL
)
GO

CREATE TABLE [Odemeler] (
    [Odeme_Id] INT IDENTITY(1,1) PRIMARY KEY,
    [Satis_Id] INT NULL FOREIGN KEY REFERENCES [Satislar]([Satis_Id]),
    [Musteri_Id] INT NULL FOREIGN KEY REFERENCES [Musteriler]([Musteri_Id]),
    [OdemeTipi] NVARCHAR(20) NOT NULL, -- Nakit, Kart
    [Tutar] DECIMAL(18,2) NOT NULL,
    [Tarih] DATETIME NOT NULL DEFAULT GETDATE()
)
GO

CREATE TABLE [Tedarikciler] (
    [Tedarikci_Id] INT IDENTITY(1,1) PRIMARY KEY,
    [FirmaAdi] NVARCHAR(100) NOT NULL,
    [Iletisim] NVARCHAR(100) NULL
)
GO

CREATE TABLE [Alimlar] (
    [Alim_Id] INT IDENTITY(1,1) PRIMARY KEY,
    [Tedarikci_Id] INT NOT NULL FOREIGN KEY REFERENCES [Tedarikciler]([Tedarikci_Id]),
    [Urun_Id] INT NOT NULL FOREIGN KEY REFERENCES [Urunler]([Urun_Id]),
    [Miktar] INT NOT NULL,
    [Birim_Alis_Fiyati] DECIMAL(18,2) NOT NULL,
    [Alim_Tarihi] DATETIME NOT NULL DEFAULT GETDATE()
)
GO

-- Örnek Veriler
INSERT INTO Urunler (Barkod, Ad, Kategori, Adet, Alis_Fiyati, Satis_Fiyati, Kritik_Stok_Seviyesi) VALUES ('1234567890123', 'Ekmek', 'Gıda', 100, 5.0, 7.5, 20);
INSERT INTO Urunler (Barkod, Ad, Kategori, Adet, Alis_Fiyati, Satis_Fiyati, Kritik_Stok_Seviyesi) VALUES ('1234567890124', 'Süt 1L', 'Gıda', 50, 15.0, 20.0, 10);
INSERT INTO Urunler (Barkod, Ad, Kategori, Adet, Alis_Fiyati, Satis_Fiyati, Kritik_Stok_Seviyesi) VALUES ('1234567890125', 'Su 5L', 'İçecek', 30, 8.0, 12.0, 10);

INSERT INTO Musteriler (Ad, Soyad, Telefon, Guncel_Borc) VALUES ('Ahmet', 'Yılmaz', '5551234567', 0);
INSERT INTO Tedarikciler (FirmaAdi, Iletisim) VALUES ('Toptancı Gıda A.Ş.', '02120000000');
GO
