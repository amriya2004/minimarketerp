$ErrorActionPreference = "Stop"
dotnet new sln -n MiniMarketERP
dotnet new classlib -n MiniMarketERP.Entities --framework net8.0
dotnet new classlib -n MiniMarketERP.DataAccess --framework net8.0
dotnet new classlib -n MiniMarketERP.Business --framework net8.0
dotnet new winforms -n MiniMarketERP.UI --framework net8.0-windows

dotnet sln add MiniMarketERP.Entities/MiniMarketERP.Entities.csproj
dotnet sln add MiniMarketERP.DataAccess/MiniMarketERP.DataAccess.csproj
dotnet sln add MiniMarketERP.Business/MiniMarketERP.Business.csproj
dotnet sln add MiniMarketERP.UI/MiniMarketERP.UI.csproj

dotnet add MiniMarketERP.DataAccess/MiniMarketERP.DataAccess.csproj reference MiniMarketERP.Entities/MiniMarketERP.Entities.csproj
dotnet add MiniMarketERP.Business/MiniMarketERP.Business.csproj reference MiniMarketERP.DataAccess/MiniMarketERP.DataAccess.csproj
dotnet add MiniMarketERP.Business/MiniMarketERP.Business.csproj reference MiniMarketERP.Entities/MiniMarketERP.Entities.csproj
dotnet add MiniMarketERP.UI/MiniMarketERP.UI.csproj reference MiniMarketERP.Business/MiniMarketERP.Business.csproj
dotnet add MiniMarketERP.UI/MiniMarketERP.UI.csproj reference MiniMarketERP.Entities/MiniMarketERP.Entities.csproj

dotnet add MiniMarketERP.DataAccess/MiniMarketERP.DataAccess.csproj package System.Data.SqlClient

Remove-Item MiniMarketERP.Entities/Class1.cs -Force -ErrorAction SilentlyContinue
Remove-Item MiniMarketERP.DataAccess/Class1.cs -Force -ErrorAction SilentlyContinue
Remove-Item MiniMarketERP.Business/Class1.cs -Force -ErrorAction SilentlyContinue
Remove-Item MiniMarketERP.UI/Form1.cs -Force -ErrorAction SilentlyContinue
Remove-Item MiniMarketERP.UI/Form1.Designer.cs -Force -ErrorAction SilentlyContinue
Remove-Item MiniMarketERP.UI/Form1.resx -Force -ErrorAction SilentlyContinue
