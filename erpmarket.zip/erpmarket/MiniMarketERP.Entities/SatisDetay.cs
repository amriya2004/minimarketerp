namespace MiniMarketERP.Entities
{
    public class SatisDetay
    {
        public int SatisDetay_Id { get; set; }
        public int Satis_Id { get; set; }
        public int Urun_Id { get; set; }
        public int Miktar { get; set; }
        public decimal BirimFiyat { get; set; }
    }
}
