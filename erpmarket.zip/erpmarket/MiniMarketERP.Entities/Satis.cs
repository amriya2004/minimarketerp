using System;

namespace MiniMarketERP.Entities
{
    public class Satis
    {
        public int Satis_Id { get; set; }
        public int? Musteri_Id { get; set; }
        public decimal Tutar { get; set; }
        public DateTime Tarih { get; set; }
        public string Satis_Durumu { get; set; }
    }
}
