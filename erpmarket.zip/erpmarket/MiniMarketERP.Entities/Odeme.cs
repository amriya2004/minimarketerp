using System;

namespace MiniMarketERP.Entities
{
    public class Odeme
    {
        public int Odeme_Id { get; set; }
        public int? Satis_Id { get; set; }
        public int? Musteri_Id { get; set; }
        public string OdemeTipi { get; set; } // Nakit, Kart
        public decimal Tutar { get; set; }
        public DateTime Tarih { get; set; }
    }
}
