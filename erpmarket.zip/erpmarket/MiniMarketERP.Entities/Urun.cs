namespace MiniMarketERP.Entities
{
    public class Urun
    {
        public int Urun_Id { get; set; }
        public string Barkod { get; set; }
        public string Ad { get; set; }
        public string Kategori { get; set; }
        public int Adet { get; set; }
        public decimal Alis_Fiyati { get; set; }
        public decimal Satis_Fiyati { get; set; }
        public int Kritik_Stok_Seviyesi { get; set; }
    }
}
