namespace MiniMarketERP.Entities
{
    public class Musteri
    {
        public int Musteri_Id { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string Telefon { get; set; }
        public string Eposta { get; set; }
        public decimal Guncel_Borc { get; set; }
    }
}
