namespace MiniMarketERP.Entities
{
    public class Tedarikci
    {
        public int Tedarikci_Id { get; set; }
        public string FirmaAdi { get; set; }
        public string Iletisim { get; set; }
    }
}
