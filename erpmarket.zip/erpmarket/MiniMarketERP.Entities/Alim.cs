using System;

namespace MiniMarketERP.Entities
{
    public class Alim
    {
        public int Alim_Id { get; set; }
        public int Tedarikci_Id { get; set; }
        public int Urun_Id { get; set; }
        public int Miktar { get; set; }
        public decimal Birim_Alis_Fiyati { get; set; }
        public DateTime Alim_Tarihi { get; set; }
    }
}
