using System;
using System.Collections.Generic;
using System.Linq;
using MiniMarketERP.DataAccess;
using MiniMarketERP.Entities;

namespace MiniMarketERP.Business
{
    public class SatisManager
    {
        private SatisDAL _satisDAL;
        private MusteriDAL _musteriDAL;
        private List<SatisDetay> _sepet;

        public SatisManager()
        {
            _satisDAL = new SatisDAL();
            _musteriDAL = new MusteriDAL();
            _sepet = new List<SatisDetay>();
        }

        public void SatisBaslat()
        {
            _sepet.Clear();
        }

        public void SepeteUrunEkle(Urun urun, int miktar = 1)
        {
            if (urun == null) throw new Exception("Ürün bulunamadı.");
            if (urun.Adet < miktar) throw new Exception("Stokta yeterli ürün yok!");

            var mevcut = _sepet.FirstOrDefault(s => s.Urun_Id == urun.Urun_Id);
            if (mevcut != null)
            {
                if (urun.Adet < mevcut.Miktar + miktar) throw new Exception("Stokta yeterli ürün yok!");
                mevcut.Miktar += miktar;
            }
            else
            {
                _sepet.Add(new SatisDetay
                {
                    Urun_Id = urun.Urun_Id,
                    Miktar = miktar,
                    BirimFiyat = urun.Satis_Fiyati
                });
            }
        }

        public void UrunCikar(int urunId)
        {
            var urun = _sepet.FirstOrDefault(s => s.Urun_Id == urunId);
            if (urun != null)
            {
                _sepet.Remove(urun);
            }
        }

        public decimal ToplamHesapla()
        {
            return _sepet.Sum(s => s.Miktar * s.BirimFiyat);
        }

        public List<SatisDetay> SepetiGetir()
        {
            return _sepet;
        }

        public int SatisTamamla(int? musteriId)
        {
            if (!_sepet.Any()) throw new Exception("Sepet boş!");
            
            decimal toplamTutar = ToplamHesapla();
            
            Satis satis = new Satis
            {
                Musteri_Id = musteriId,
                Tutar = toplamTutar,
                Tarih = DateTime.Now,
                Satis_Durumu = "Tamamlandı"
            };

            int satisId = _satisDAL.SatisKaydet(satis, _sepet);
            
            return satisId;
        }

        public System.Data.DataTable SatisListele()
        {
            return _satisDAL.SatisListele();
        }

        public void SatisIptalEt()
        {
            _sepet.Clear();
        }
    }
}
