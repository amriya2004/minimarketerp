using System;
using System.Collections.Generic;
using MiniMarketERP.DataAccess;
using MiniMarketERP.Entities;

namespace MiniMarketERP.Business
{
    public class TedarikManager
    {
        private TedarikDAL _tedarikDAL;

        public TedarikManager()
        {
            _tedarikDAL = new TedarikDAL();
        }

        public void UrunAlimKaydi(Alim alim)
        {
            if (alim.Miktar <= 0 || alim.Birim_Alis_Fiyati <= 0)
                throw new Exception("Miktar ve Alış Fiyatı 0'dan büyük olmalıdır.");

            _tedarikDAL.AlimKaydet(alim);
        }

        public List<Tedarikci> TedarikciListele()
        {
            return _tedarikDAL.TedarikciListele();
        }

        public System.Data.DataTable AlimListele()
        {
            return _tedarikDAL.AlimListele();
        }

        public void AlimGuncelle(Alim alim)
        {
            _tedarikDAL.AlimGuncelle(alim);
        }

        public void AlimSil(int alimId)
        {
            _tedarikDAL.AlimSil(alimId);
        }

        public decimal BorcSorgula(int tedarikciId)
        {
            return _tedarikDAL.BorcSorgula(tedarikciId);
        }
    }
}
