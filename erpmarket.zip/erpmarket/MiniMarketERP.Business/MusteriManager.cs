using System;
using System.Collections.Generic;
using MiniMarketERP.DataAccess;
using MiniMarketERP.Entities;

namespace MiniMarketERP.Business
{
    public class MusteriManager
    {
        private MusteriDAL _musteriDAL;

        public MusteriManager()
        {
            _musteriDAL = new MusteriDAL();
        }

        public void MusteriEkle(Musteri m)
        {
            if (string.IsNullOrWhiteSpace(m.Ad) || string.IsNullOrWhiteSpace(m.Soyad))
                throw new Exception("Ad ve Soyad boş geçilemez.");
            _musteriDAL.Ekle(m);
        }

        public void MusteriGuncelle(Musteri m)
        {
            _musteriDAL.Guncelle(m);
        }

        public void MusteriSil(int musteriId)
        {
            _musteriDAL.Sil(musteriId);
        }

        public List<Musteri> MusteriListele()
        {
            return _musteriDAL.Listele();
        }

        public decimal BorcSorgula(int musteriId)
        {
            var list = _musteriDAL.Listele();
            var musteri = list.Find(m => m.Musteri_Id == musteriId);
            return musteri != null ? musteri.Guncel_Borc : 0;
        }

        public void BorcEkle(int musteriId, decimal tutar)
        {
            _musteriDAL.BorcGuncelle(musteriId, tutar);
        }
    }
}
