using System;
using System.Data;
using System.Data.SqlClient;
using MiniMarketERP.DataAccess;

namespace MiniMarketERP.Business
{
    public class RaporManager
    {
        public DataTable GunlukCiroRaporu(DateTime tarih)
        {
            var dt = new DataTable();
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT Tarih, Satis_Durumu, Tutar FROM Satislar WHERE CAST(Tarih AS DATE) = CAST(@Tarih AS DATE)", conn);
                cmd.Parameters.AddWithValue("@Tarih", tarih);
                var adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            return dt;
        }

        public DataTable EnCokSatanUrunler()
        {
            var dt = new DataTable();
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT u.Ad, u.Barkod, SUM(sd.Miktar) as ToplamSatis FROM SatisDetaylari sd INNER JOIN Urunler u ON sd.Urun_Id = u.Urun_Id GROUP BY u.Ad, u.Barkod ORDER BY ToplamSatis DESC", conn);
                var adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            return dt;
        }

        public DataTable StokDurumRaporu()
        {
            var dt = new DataTable();
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT Barkod, Ad, Adet, Kritik_Stok_Seviyesi FROM Urunler", conn);
                var adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            return dt;
        }

        public DataTable KarZararRaporu()
        {
            var dt = new DataTable();
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand(@"SELECT u.Ad, SUM(sd.Miktar) as SatisMiktari, 
                                           SUM(sd.Miktar * u.Alis_Fiyati) as ToplamMaliyet, 
                                           SUM(sd.Miktar * sd.BirimFiyat) as ToplamSatis, 
                                           (SUM(sd.Miktar * sd.BirimFiyat) - SUM(sd.Miktar * u.Alis_Fiyati)) as KarZarar 
                                           FROM SatisDetaylari sd 
                                           INNER JOIN Urunler u ON sd.Urun_Id = u.Urun_Id 
                                           GROUP BY u.Ad", conn);
                var adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            return dt;
        }

        public DataTable SatisRaporuFiltrele(DateTime baslangic, DateTime bitis)
        {
            var dt = new DataTable();
            using (var conn = DbHelper.GetConnection())
            {
                var cmd = new SqlCommand("SELECT Satis_Id, Musteri_Id, Tutar, Tarih, Satis_Durumu FROM Satislar WHERE Tarih >= @Baslangic AND Tarih <= @Bitis", conn);
                cmd.Parameters.AddWithValue("@Baslangic", baslangic);
                cmd.Parameters.AddWithValue("@Bitis", bitis);
                var adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            return dt;
        }
    }
}
