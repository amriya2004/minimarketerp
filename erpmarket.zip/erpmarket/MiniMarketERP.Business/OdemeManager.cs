using System;
using MiniMarketERP.DataAccess;
using MiniMarketERP.Entities;

namespace MiniMarketERP.Business
{
    public class OdemeManager
    {
        private OdemeDAL _odemeDAL;
        private MusteriDAL _musteriDAL;

        public OdemeManager()
        {
            _odemeDAL = new OdemeDAL();
            _musteriDAL = new MusteriDAL();
        }

        public void OdemeAl(Odeme odeme)
        {
            if (odeme.Tutar <= 0) throw new Exception("Tutar 0'dan büyük olmalıdır.");
            
            _odemeDAL.OdemeKaydet(odeme);

            // Eğer veresiye borcu ödeniyorsa
            if (odeme.Musteri_Id.HasValue && !odeme.Satis_Id.HasValue)
            {
                // Müşterinin borcunu düş
                _musteriDAL.BorcGuncelle(odeme.Musteri_Id.Value, -odeme.Tutar);
            }
        }

        public System.Data.DataTable OdemeListele()
        {
            return _odemeDAL.OdemeListele();
        }

        public void IadeIslemi(Odeme odeme)
        {
            _odemeDAL.IadeKaydet(odeme);
            if (odeme.Musteri_Id.HasValue && !odeme.Satis_Id.HasValue)
            {
                // Müşteriye iade yapıldığında borcu geri yüklenir
                _musteriDAL.BorcGuncelle(odeme.Musteri_Id.Value, Math.Abs(odeme.Tutar));
            }
        }

        public string FisOlustur(int odemeId)
        {
            // Fiş oluşturma metni
            return $"--- FİŞ ---\nÖdeme No: {odemeId}\nTarih: {DateTime.Now}\nTeşekkür ederiz!";
        }
    }
}
