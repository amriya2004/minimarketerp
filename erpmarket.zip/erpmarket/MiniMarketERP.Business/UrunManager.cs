using System;
using System.Collections.Generic;
using MiniMarketERP.DataAccess;
using MiniMarketERP.Entities;

namespace MiniMarketERP.Business
{
    public class UrunManager
    {
        private UrunDAL _urunDAL;

        public UrunManager()
        {
            _urunDAL = new UrunDAL();
        }

        public void UrunEkle(Urun urun)
        {
            if (string.IsNullOrWhiteSpace(urun.Ad) || urun.Satis_Fiyati <= 0)
                throw new Exception("Ürün adı boş olamaz ve satış fiyatı 0'dan büyük olmalıdır.");

            if (string.IsNullOrWhiteSpace(urun.Barkod))
                urun.Barkod = BarkodOlustur();

            _urunDAL.Ekle(urun);
        }

        public void UrunGuncelle(Urun urun)
        {
            if (urun.Urun_Id <= 0) throw new Exception("Geçersiz ürün ID.");
            _urunDAL.Guncelle(urun);
        }

        public void UrunSil(int urunId)
        {
            _urunDAL.Sil(urunId);
        }

        public List<Urun> StokListele()
        {
            return _urunDAL.Listele();
        }

        public Urun BarkodaGoreGetir(string barkod)
        {
            return _urunDAL.BarkodaGoreGetir(barkod);
        }

        public List<Urun> KritikStokKontrol()
        {
            var tumUrunler = _urunDAL.Listele();
            var kritikUrunler = new List<Urun>();
            foreach (var u in tumUrunler)
            {
                if (u.Adet <= u.Kritik_Stok_Seviyesi)
                {
                    kritikUrunler.Add(u);
                }
            }
            return kritikUrunler;
        }

        public string BarkodOlustur()
        {
            // Basit bir barkod üretimi (Ticks tabanlı)
            return DateTime.Now.Ticks.ToString().Substring(0, 13);
        }
    }
}
