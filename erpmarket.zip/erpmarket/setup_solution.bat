@echo off
echo MiniMarketERP Solution olusturuluyor...
dotnet new sln -n MiniMarketERP
dotnet sln add MiniMarketERP.Entities\MiniMarketERP.Entities.csproj
dotnet sln add MiniMarketERP.DataAccess\MiniMarketERP.DataAccess.csproj
dotnet sln add MiniMarketERP.Business\MiniMarketERP.Business.csproj
dotnet sln add MiniMarketERP.UI\MiniMarketERP.UI.csproj
echo Islemler tamamlandi. Visual Studio ile MiniMarketERP.sln dosyasini acabilirsiniz.
pause
